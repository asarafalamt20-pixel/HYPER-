import express from "express";
import cors from "cors";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import Database from "better-sqlite3";
import multer from "multer";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const app=express();
const PORT=process.env.PORT||3000;
const JWT_SECRET=process.env.JWT_SECRET||"CHANGE_THIS_SECRET";

const dataDir=path.join(__dirname,"data"), uploadDir=path.join(__dirname,"uploads");
fs.mkdirSync(dataDir,{recursive:true}); fs.mkdirSync(uploadDir,{recursive:true});
const db=new Database(path.join(dataDir,"hyper.db"));
db.pragma("journal_mode=WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, email TEXT UNIQUE NOT NULL, password TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS videos(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, title TEXT NOT NULL, description TEXT DEFAULT '', filename TEXT NOT NULL, original_name TEXT, category TEXT DEFAULT 'trending', views INTEGER DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id));
CREATE TABLE IF NOT EXISTS likes(user_id INTEGER NOT NULL, video_id INTEGER NOT NULL, UNIQUE(user_id,video_id));
CREATE TABLE IF NOT EXISTS comments(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,video_id INTEGER NOT NULL,text TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS subscriptions(subscriber_id INTEGER NOT NULL,channel_id INTEGER NOT NULL,UNIQUE(subscriber_id,channel_id));
`);

const storage=multer.diskStorage({
 destination:(_,__,cb)=>cb(null,uploadDir),
 filename:(_,file,cb)=>cb(null,Date.now()+"-"+Math.random().toString(36).slice(2)+path.extname(file.originalname))
});
const upload=multer({storage,limits:{fileSize:1024*1024*1024},fileFilter:(_,file,cb)=>cb(null,file.mimetype.startsWith("video/"))});
app.use(cors()); app.use(express.json()); app.use(express.urlencoded({extended:true}));
app.use("/uploads",express.static(uploadDir)); app.use(express.static(path.join(__dirname,"public")));

function auth(req,res,next){
 const h=req.headers.authorization||""; const token=h.startsWith("Bearer ")?h.slice(7):null;
 if(!token) return res.status(401).json({error:"Login required"});
 try{req.user=jwt.verify(token,JWT_SECRET);next()}catch{return res.status(401).json({error:"Invalid/expired login"})}
}
function token(u){return jwt.sign({id:u.id,username:u.username},JWT_SECRET,{expiresIn:"30d"})}

app.post("/api/auth/register",(req,res)=>{
 const {username,email,password}=req.body;
 if(!username||!email||!password||password.length<6)return res.status(400).json({error:"Username, email and 6+ character password required"});
 try{const hash=bcrypt.hashSync(password,10);const info=db.prepare("INSERT INTO users(username,email,password) VALUES(?,?,?)").run(username.trim(),email.trim().toLowerCase(),hash);const u=db.prepare("SELECT id,username,email FROM users WHERE id=?").get(info.lastInsertRowid);res.json({token:token(u),user:u})}
 catch(e){res.status(400).json({error:"Username or email already exists"})}
});
app.post("/api/auth/login",(req,res)=>{
 const {email,password}=req.body; const u=db.prepare("SELECT * FROM users WHERE email=?").get((email||"").trim().toLowerCase());
 if(!u||!bcrypt.compareSync(password||"",u.password))return res.status(401).json({error:"Wrong email or password"});
 res.json({token:token(u),user:{id:u.id,username:u.username,email:u.email}})
});
app.get("/api/me",auth,(req,res)=>res.json(db.prepare("SELECT id,username,email,created_at FROM users WHERE id=?").get(req.user.id)));

app.get("/api/videos",(req,res)=>{
 const q=(req.query.q||"").trim(), cat=req.query.category;
 let sql=`SELECT v.*,u.username, (SELECT COUNT(*) FROM likes l WHERE l.video_id=v.id) likes, (SELECT COUNT(*) FROM comments c WHERE c.video_id=v.id) comments FROM videos v JOIN users u ON u.id=v.user_id`;
 const params=[]; const where=[];
 if(q){where.push("(v.title LIKE ? OR v.description LIKE ?)");params.push("%"+q+"%","%"+q+"%")}
 if(cat&&cat!=="all"){where.push("v.category=?");params.push(cat)}
 if(where.length)sql+=" WHERE "+where.join(" AND ");
 sql+=" ORDER BY v.created_at DESC";
 res.json(db.prepare(sql).all(...params).map(v=>({...v,url:"/uploads/"+v.filename})));
});
app.get("/api/videos/:id", (req,res)=>{
 const v=db.prepare(`SELECT v.*,u.username,(SELECT COUNT(*) FROM likes WHERE video_id=v.id) likes,(SELECT COUNT(*) FROM comments WHERE video_id=v.id) comments FROM videos v JOIN users u ON u.id=v.user_id WHERE v.id=?`).get(req.params.id);
 if(!v)return res.status(404).json({error:"Video not found"}); res.json({...v,url:"/uploads/"+v.filename});
});
app.post("/api/videos",auth,upload.single("video"),(req,res)=>{
 if(!req.file)return res.status(400).json({error:"Video file required"});
 const title=(req.body.title||"Untitled video").trim();
 const info=db.prepare("INSERT INTO videos(user_id,title,description,filename,original_name,category) VALUES(?,?,?,?,?,?)")
 .run(req.user.id,title,req.body.description||"",req.file.filename,req.file.originalname,req.body.category||"trending");
 const v=db.prepare("SELECT * FROM videos WHERE id=?").get(info.lastInsertRowid); res.json({...v,url:"/uploads/"+v.filename});
});
app.post("/api/videos/:id/view",(req,res)=>{db.prepare("UPDATE videos SET views=views+1 WHERE id=?").run(req.params.id);res.json({ok:true})});
app.post("/api/videos/:id/like",auth,(req,res)=>{
 const id=+req.params.id, old=db.prepare("SELECT 1 FROM likes WHERE user_id=? AND video_id=?").get(req.user.id,id);
 if(old)db.prepare("DELETE FROM likes WHERE user_id=? AND video_id=?").run(req.user.id,id);else db.prepare("INSERT OR IGNORE INTO likes VALUES(?,?)").run(req.user.id,id);
 res.json({liked:!old});
});
app.get("/api/videos/:id/comments",(req,res)=>res.json(db.prepare(`SELECT c.*,u.username FROM comments c JOIN users u ON u.id=c.user_id WHERE c.video_id=? ORDER BY c.created_at DESC`).all(req.params.id)));
app.post("/api/videos/:id/comments",auth,(req,res)=>{
 const text=(req.body.text||"").trim();if(!text)return res.status(400).json({error:"Comment required"});
 const info=db.prepare("INSERT INTO comments(user_id,video_id,text) VALUES(?,?,?)").run(req.user.id,+req.params.id,text);
 res.json(db.prepare(`SELECT c.*,u.username FROM comments c JOIN users u ON u.id=c.user_id WHERE c.id=?`).get(info.lastInsertRowid));
});
app.post("/api/subscribe/:channelId",auth,(req,res)=>{
 const cid=+req.params.channelId;if(cid===req.user.id)return res.status(400).json({error:"Cannot subscribe to yourself"});
 const old=db.prepare("SELECT 1 FROM subscriptions WHERE subscriber_id=? AND channel_id=?").get(req.user.id,cid);
 if(old)db.prepare("DELETE FROM subscriptions WHERE subscriber_id=? AND channel_id=?").run(req.user.id,cid);else db.prepare("INSERT OR IGNORE INTO subscriptions VALUES(?,?)").run(req.user.id,cid);
 res.json({subscribed:!old});
});
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log("HYPER running on http://localhost:"+PORT));